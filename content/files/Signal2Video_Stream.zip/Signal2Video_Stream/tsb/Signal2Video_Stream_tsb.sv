`timescale 1ns/100ps

module Signal2Video_Stream_tsb;

  // Parameters
  localparam T1 = 17; // SAMPLE_CLK period 60MHz
  localparam T2 = 10; // PIXEL_CLK period 100MHz

  //Ports
  logic signed [15:0] WAVE;
  logic signed [15:0] WAVE_2;
  logic SAMPLE_CLK;
  logic [1:0] MODO;
  logic RESET_n;
  logic DRAW_DOT;
  logic PIXEL_CLK;
  logic [39:0] avalon_data;
  logic avalon_valid;
  logic avalon_ready;
  logic [2:0] ready_seq_idx;
  logic avalon_startofpacket;
  logic avalon_endofpacket;
  logic [31:0] SCAL;
  logic START_STOP;

  int VSD_count;
  int i;
  int unsigned sample_idx;
  int unsigned pixel_count_frame;
  int unsigned frame_count;
  integer pixel_log_fd;

  Signal2Video_Stream #(
    .VIEW_X_MIN   (20),
    .VIEW_X_MAX   (400),
    .VIEW_Y_MIN   (40),
    .VIEW_Y_MAX   (400)
  ) Signal2Video_inst (
    .WAVE(WAVE),
    .WAVE_2(WAVE_2),
    .SAMPLE_CLK(SAMPLE_CLK),
    .MODO(MODO),
    .RESET_n(RESET_n),
    .DRAW_DOT(DRAW_DOT),
    .PIXEL_CLK(PIXEL_CLK),
    .avalon_data(avalon_data),
    .avalon_valid(avalon_valid),
    .avalon_ready(avalon_ready),
    .avalon_startofpacket(avalon_startofpacket),
    .avalon_endofpacket(avalon_endofpacket),
    .SCAL(SCAL),
    .START_STOP(START_STOP)
  );

// Clock generation
  always #(T1/2) SAMPLE_CLK = ~SAMPLE_CLK;
  always #(T2/2) PIXEL_CLK = ~PIXEL_CLK;

  initial begin
    i = 0;
    sample_idx = 0;

    pixel_log_fd = $fopen("../../../tsb/stream_pixels.csv", "w");
    if (pixel_log_fd == 0) begin
      $fatal(1, "No se pudo abrir ../../../tsb/stream_pixels.csv para escritura");
    end
    $fwrite(pixel_log_fd, "time_ns,frame,pixel,data_hex,startofpacket,endofpacket\n");

    SAMPLE_CLK = 0;
    PIXEL_CLK = 0;
    MODO = 2'b11;
    WAVE = 16'h0000;
    WAVE_2 = 16'h0000;
    SCAL = 5; // Example scaling factor
    START_STOP = 1;
    DRAW_DOT = 0;
    RESET_n = 0; // Start with reset active
    
    
    #(T1*2); // Hold reset for a few cycles
    RESET_n = 1; // Release reset

    @(posedge avalon_endofpacket);

    @(posedge avalon_endofpacket);
    DRAW_DOT = 1; // Activar dibujo de puntos
    SCAL = 10;

    @(posedge avalon_endofpacket);
    DRAW_DOT = 0;

    @(posedge avalon_endofpacket);

    $display("Test completed.");
    $fclose(pixel_log_fd);
    $stop;
    
  end

  // Generador continuo de seno/coseno: un dato nuevo por ciclo de SAMPLE_CLK
  always @(negedge SAMPLE_CLK) begin
    WAVE   <= $rtoi($sin(2.0 * 3.14159 * sample_idx / 500.0) * 32767.0);
    WAVE_2 <= $rtoi($sin(2.0 * 3.14159 * sample_idx / 1000.0) * 32767.0);
    sample_idx <= sample_idx + 1;
  end

  // Backpressure aleatorio en avalon_ready para probar robustez 
  // del DUT ante condiciones variables de ready
  always_ff @(posedge PIXEL_CLK or negedge RESET_n) begin
    if (!RESET_n)
      avalon_ready <= 1'b1;
    else
      avalon_ready <= $urandom_range(0, 1); // Backpressure aleatorio para probar robustez del DUT ante condiciones variables de ready
    end

  // Cuenta los píxeles transmitidos por frame
  always_ff @(negedge PIXEL_CLK or negedge RESET_n) begin
    if (!RESET_n) begin
      pixel_count_frame <= 0;
      VSD_count <= 0;
      frame_count <= 0;
    end
    else if (avalon_valid) begin
      int unsigned pixel_to_log;

      if (avalon_startofpacket)
        pixel_count_frame <= 1;
      else
        pixel_count_frame <= pixel_count_frame + 1;

      if (avalon_startofpacket)
        pixel_to_log = 1;
      else
        pixel_to_log = pixel_count_frame + 1;

      // Log de cada píxel del stream con SOP/EOP para postprocesado/dibujo
      $fwrite(pixel_log_fd, "%0t,%0d,%0d,0x%010h,%0b,%0b\n",
              $time, frame_count, pixel_to_log,
              avalon_data, avalon_startofpacket, avalon_endofpacket);

      if (avalon_endofpacket) begin
        if (avalon_startofpacket)
          $display("Pixels frame: %0d", 1);
        else
          $display("Pixels frame: %0d", pixel_count_frame + 1);

        VSD_count <= VSD_count + 1;
        frame_count <= frame_count + 1;
        $display("VSD Count: %0d", VSD_count + 1);
      end
    end
  end

endmodule