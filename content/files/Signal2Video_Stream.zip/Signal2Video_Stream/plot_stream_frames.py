#!/usr/bin/env python3
"""Lee un CSV de píxeles Avalon-ST y dibuja cada frame en una figura distinta.

Formato esperado del CSV (como en el testbench):
    time_ns,frame,pixel,data_hex,startofpacket,endofpacket
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np


Row = Dict[str, str]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Dibuja cada frame del streaming en una figura distinta"
    )
    parser.add_argument(
        "csv_file",
        nargs="?",
        default="tsb/stream_pixels.csv",
        help="Ruta al fichero CSV (por defecto: tsb/stream_pixels.csv)",
    )
    parser.add_argument(
        "--width",
        type=int,
        default=640,
        help="Ancho de imagen (por defecto: 640)",
    )
    parser.add_argument(
        "--height",
        type=int,
        default=480,
        help="Alto de imagen (por defecto: 480)",
    )
    parser.add_argument(
        "--output-dir",
        default="frames_png",
        help="Directorio donde guardar los PNG (por defecto: frames_png)",
    )
    return parser.parse_args()


def to_bool(value: str) -> bool:
    v = value.strip().lower()
    return v in {"1", "true", "t", "yes", "y"}


def parse_data_hex(value: str) -> int:
    v = value.strip()
    return int(v, 16) if v.lower().startswith("0x") else int(v)


def unpack_argb10(pixel40: int) -> Tuple[int, int, int, int]:
    # avalon_data = {alpha[9:0], red[9:0], green[9:0], blue[9:0]}
    blue = pixel40 & 0x3FF
    green = (pixel40 >> 10) & 0x3FF
    red = (pixel40 >> 20) & 0x3FF
    alpha = (pixel40 >> 30) & 0x3FF
    return alpha, red, green, blue


def argb10_to_rgb8(alpha: int, red: int, green: int, blue: int) -> np.ndarray:
    # Conversión a 8-bit y aplicación de alpha sobre fondo negro
    a = alpha / 1023.0
    r8 = int(round((red / 1023.0) * a * 255.0))
    g8 = int(round((green / 1023.0) * a * 255.0))
    b8 = int(round((blue / 1023.0) * a * 255.0))
    return np.array([r8, g8, b8], dtype=np.uint8)


def read_rows(csv_path: Path) -> Tuple[List[Row], Optional[int]]:
    with csv_path.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        required = {
            "time_ns",
            "frame",
            "pixel",
            "data_hex",
            "startofpacket",
            "endofpacket",
        }
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            raise ValueError(
                "CSV inválido. Debe contener cabeceras: "
                "time_ns,frame,pixel,data_hex,startofpacket,endofpacket"
            )

        rows: List[Row] = []
        # +2 para convertir índice del DictReader a línea real del fichero
        # (cabecera = línea 1, primera fila de datos = línea 2).
        for row_idx, row in enumerate(reader):
            is_incomplete = (
                (None in row)
                or any(row.get(k) is None for k in required)
                or any(str(row.get(k, "")).strip() == "" for k in required)
            )
            if is_incomplete:
                return rows, row_idx + 2
            rows.append(row)

        return rows, None


def split_frames(rows: List[Row]) -> List[List[Row]]:
    # Preferimos separar por SOP/EOP si existen en el stream.
    frames: List[List[Row]] = []
    current: List[Row] = []
    saw_control = False

    for row in rows:
        sop = to_bool(row.get("startofpacket", "0"))
        eop = to_bool(row.get("endofpacket", "0"))

        if sop or eop:
            saw_control = True

        if sop and current:
            frames.append(current)
            current = []

        current.append(row)

        if eop:
            frames.append(current)
            current = []

    if current:
        frames.append(current)

    if saw_control:
        return frames

    # Fallback: agrupar por columna frame
    by_frame: Dict[int, List[Row]] = {}
    for row in rows:
        frame_id = int(row["frame"])
        by_frame.setdefault(frame_id, []).append(row)

    return [by_frame[k] for k in sorted(by_frame.keys())]


def build_image(frame_rows: List[Row], width: int, height: int) -> np.ndarray:
    n_pixels = width * height
    img = np.zeros((height, width, 3), dtype=np.uint8)
    filled = np.zeros(n_pixels, dtype=bool)
    next_linear_idx = 0

    for row in frame_rows:
        # Intentar usar el índice de píxel del CSV (base 1)
        idx = None
        try:
            p = int(row.get("pixel", "0")) - 1
            if 0 <= p < n_pixels and not filled[p]:
                idx = p
        except ValueError:
            idx = None

        # Fallback lineal si no hay índice válido
        if idx is None:
            while next_linear_idx < n_pixels and filled[next_linear_idx]:
                next_linear_idx += 1
            if next_linear_idx >= n_pixels:
                break
            idx = next_linear_idx

        pixel40 = parse_data_hex(row["data_hex"])
        a, r, g, b = unpack_argb10(pixel40)
        rgb = argb10_to_rgb8(a, r, g, b)

        y, x = divmod(idx, width)
        img[y, x, :] = rgb
        filled[idx] = True

    # Si el frame quedó incompleto, pintar de verde los píxeles restantes.
    if not np.all(filled):
        img.reshape(-1, 3)[~filled] = np.array([0, 255, 0], dtype=np.uint8)

    return img


def main() -> None:
    args = parse_args()
    csv_path = Path(args.csv_file)
    output_dir = Path(args.output_dir)

    if args.width <= 0 or args.height <= 0:
        raise ValueError("width y height deben ser > 0")

    if not csv_path.exists():
        raise FileNotFoundError(f"No existe el fichero CSV: {csv_path}")

    rows, incomplete_line = read_rows(csv_path)
    if not rows:
        if incomplete_line is not None:
            raise ValueError(
                f"Se detectó una línea incompleta en el CSV (línea {incomplete_line}) "
                "antes de cualquier píxel válido."
            )
        raise ValueError("El CSV está vacío")

    frames = split_frames(rows)
    if not frames:
        raise ValueError("No se detectaron frames en el CSV")

    output_dir.mkdir(parents=True, exist_ok=True)

    for i, frame_rows in enumerate(frames):
        img = build_image(frame_rows, args.width, args.height)
        png_path = output_dir / f"frame_{i:04d}.png"
        plt.imsave(png_path, img)
        print(f"Guardado frame {i} con {len(frame_rows)} píxeles en: {png_path.resolve()}")

        fig, ax = plt.subplots(num=f"Frame {i}")
        ax.imshow(img, origin="upper", interpolation="nearest")
        ax.set_title(f"Frame {i} - {len(frame_rows)} píxeles en CSV")
        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.grid(False)

    print(f"Guardados {len(frames)} frame(s) en: {output_dir.resolve()}")

    if incomplete_line is not None:
        print(
            "Se detectó una línea incompleta en el CSV "
            f"(línea {incomplete_line}). "
            "Se generó la imagen actual hasta el píxel anterior y se detiene el script."
        )
        return

    # plt.show()


if __name__ == "__main__":
    main()
