module	Video_AvalonST_Frame_Generator(
                        // Host Side
                        iAlpha,
                        iRed,
                        iGreen,
                        iBlue,
                        oRequest,
                        // Avalon Streaming Interface
                        avalon_data,
                        avalon_valid,
                        avalon_ready,
                        avalon_startofpacket,
                        avalon_endofpacket,
                        
                        oFrameSync,
                        hCount,
                        vCount,
                        // Control Signal
                        iCLK,
                        iRST_N
                        );

//	Horizontal timing segments (pixels)
parameter	H_BLANK_LEAD	=	1;
parameter	H_BLANK_PRE	=	46;
parameter	H_ACTIVE_PIX	=	800;
parameter	H_BLANK_POST	=	210;
parameter int CTRL_PIPE_STAGES = 2;

//	Vertical timing segments (lines)
parameter	V_BLANK_LEAD	=	1;
parameter	V_BLANK_PRE	=	23;
parameter	V_ACTIVE_LINES	=	480;
parameter	V_BLANK_POST	=	22;

// Host Side
input		[9:0]	iAlpha;
input		[9:0]	iRed;
input		[9:0]	iGreen;
input		[9:0]	iBlue;
output	logic			oRequest;

// Avalon Streaming Interface
output	reg	[39:0]	avalon_data; // 10 bits per canal: {Alpha, Red, Green, Blue}
output	reg			avalon_valid;
input				avalon_ready;
output	reg			avalon_startofpacket;
output	reg			avalon_endofpacket;
output	reg			oFrameSync;
output reg [$clog2(H_BLANK_LEAD+H_BLANK_PRE+H_ACTIVE_PIX+H_BLANK_POST)-1:0]		hCount;
output reg [$clog2(V_BLANK_LEAD+V_BLANK_PRE+V_ACTIVE_LINES+V_BLANK_POST)-1:0]		vCount;
// Control Signal
input				iCLK;
input				iRST_N;

localparam int H_TOTAL      = H_BLANK_LEAD + H_BLANK_PRE + H_ACTIVE_PIX + H_BLANK_POST;
localparam int V_TOTAL      = V_BLANK_LEAD + V_BLANK_PRE + V_ACTIVE_LINES + V_BLANK_POST;
localparam int H_ACTIVE_INI = H_BLANK_LEAD + H_BLANK_PRE;
localparam int H_ACTIVE_END = H_ACTIVE_INI + H_ACTIVE_PIX - 1;
localparam int V_ACTIVE_INI = V_BLANK_LEAD + V_BLANK_PRE;
localparam int V_ACTIVE_END = V_ACTIVE_INI + V_ACTIVE_LINES - 1;

wire h_active;
wire v_active;
wire in_active;
wire first_active_pixel;
wire last_active_pixel;
logic [CTRL_PIPE_STAGES-1:0] avalon_valid_pipe;
logic [CTRL_PIPE_STAGES-1:0] avalon_startofpacket_pipe;
logic [CTRL_PIPE_STAGES-1:0] avalon_endofpacket_pipe;

assign h_active           = (hCount >= H_ACTIVE_INI) && (hCount <= H_ACTIVE_END);
assign v_active           = (vCount >= V_ACTIVE_INI) && (vCount <= V_ACTIVE_END);
assign in_active          = h_active && v_active;
assign first_active_pixel = (hCount == H_ACTIVE_INI) && (vCount == V_ACTIVE_INI);
assign last_active_pixel  = (hCount == H_ACTIVE_END) && (vCount == V_ACTIVE_END);

always_ff @(posedge iCLK or negedge iRST_N) begin
    integer i;
    if (!iRST_N) begin
        hCount               <= '0;
        vCount               <= '0;
        avalon_data          <= '0;
        avalon_valid         <= 1'b0;
        avalon_startofpacket <= 1'b0;
        avalon_endofpacket   <= 1'b0;
        avalon_valid_pipe       <= '0;
        avalon_startofpacket_pipe <= '0;
        avalon_endofpacket_pipe <= '0;
        oRequest             <= 1'b0;
        oFrameSync           <= 1'b0;
    end
    else begin
        avalon_data          <= {iAlpha, iRed, iGreen, iBlue};

        // Control con pipeline parametrizable para alinear con la latencia de datos.
        // Además, valid depende de ready para no llenar FIFO intermedia.
        avalon_valid_pipe[0]         <= in_active & avalon_ready;
        avalon_startofpacket_pipe[0] <= in_active && first_active_pixel;
        avalon_endofpacket_pipe[0]   <= in_active && last_active_pixel;

        for (i = 1; i < CTRL_PIPE_STAGES; i = i + 1) begin
            avalon_valid_pipe[i]         <= avalon_valid_pipe[i-1];
            avalon_startofpacket_pipe[i] <= avalon_startofpacket_pipe[i-1];
            avalon_endofpacket_pipe[i]   <= avalon_endofpacket_pipe[i-1];
        end

        avalon_valid         <= avalon_valid_pipe[CTRL_PIPE_STAGES-1];
        avalon_startofpacket <= avalon_startofpacket_pipe[CTRL_PIPE_STAGES-1];
        avalon_endofpacket   <= avalon_endofpacket_pipe[CTRL_PIPE_STAGES-1];

        oRequest             <= in_active;

        // Pulso periódico de inicio de frame
        oFrameSync           <= (vCount < V_BLANK_LEAD);

        // Backpressure: si ready=0, se congela el barrido/flujo
        if (avalon_ready | ~in_active) begin
            if (hCount == H_TOTAL-1) begin
                hCount <= '0;
                if (vCount == V_TOTAL-1)
                    vCount <= '0;
                else
                    vCount <= vCount + 1'b1;
            end
            else begin
                hCount <= hCount + 1'b1;
            end
        end
    end
end


endmodule