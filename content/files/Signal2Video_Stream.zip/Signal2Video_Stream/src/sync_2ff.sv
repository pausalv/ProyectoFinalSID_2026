module sync_2ff #(
  parameter int WIDTH = 1
)(
  input logic clk,
  input logic [WIDTH-1:0] in_signal,
  output logic [WIDTH-1:0] out_signal
);

  logic [WIDTH-1:0] sync_ff1;
  logic [WIDTH-1:0] sync_ff2;

  // Two flip-flop synchronizer to mitigate metastability
  always_ff @(posedge clk) begin
    sync_ff1 <= in_signal;
    sync_ff2 <= sync_ff1;
  end


  // Output is the synchronized signal from the second flip-flop
  assign out_signal = sync_ff2;

endmodule