module cdc_sync #(
    parameter int WIDTH = 8
) (
    input  logic        clk_src, //c1
    input  logic        clk_dst, //c2
    input  logic        rst_n,
    input  logic [WIDTH-1:0] data_src,
    input  logic        valid_src,
    output logic [WIDTH-1:0] data_dst,
    output logic        valid_dst
);

  logic [WIDTH-1:0] c1_data, c1_data_reg;
  logic             c1_valid;
  logic             c1_qual_toggle;
  logic             c2_qual_toggle;
  logic             c2_qual_toggle_reg;
  logic             c2_qual_toggle_det;

  always_ff @(posedge clk_src or negedge rst_n)
    if(!rst_n) begin
      c1_data <= '0;
      c1_valid <= 1'b0;
    end
    else begin
      c1_data <= data_src;
      c1_valid <= valid_src;
    end
  
  always_ff @(posedge clk_src or negedge rst_n)
    if(!rst_n) begin
      c1_data_reg <= '0;
      c1_qual_toggle <= 1'b0;
    end
    else begin
      c1_qual_toggle <= c1_valid ^ c1_qual_toggle;
    
      if(c1_valid)
        c1_data_reg <= c1_data;

    end

  sync_2ff #(.WIDTH(1)) sync_toggle (
    .clk(clk_dst),
    .in_signal(c1_qual_toggle),
    .out_signal(c2_qual_toggle)
  );

  always_ff @(posedge clk_dst or negedge rst_n) begin
    if(!rst_n)
      c2_qual_toggle_reg <= 1'b0;
    else
      c2_qual_toggle_reg <= c2_qual_toggle;
  end

  assign c2_qual_toggle_det = c2_qual_toggle ^ c2_qual_toggle_reg;

  always_ff @(posedge clk_dst or negedge rst_n) begin
    if(!rst_n) begin
      data_dst <= '0;
      valid_dst <= 1'b0;
    end
    else begin
      if(c2_qual_toggle_det) 
        data_dst <= c1_data_reg;
      valid_dst <= c2_qual_toggle_det;
    end
    
  end 

endmodule