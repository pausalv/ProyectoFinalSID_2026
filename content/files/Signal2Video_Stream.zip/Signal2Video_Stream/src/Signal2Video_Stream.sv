
module Signal2Video_Stream #(
    parameter int H_SYNC_CYC   = 96,
    parameter int H_SYNC_BACK  = 48,
    parameter int H_SYNC_ACT   = 640,
    parameter int H_SYNC_FRONT = 16,
    parameter int V_SYNC_BACK  = 33,
    parameter int V_SYNC_ACT   = 480,
    parameter int V_SYNC_CYC   = 1,
    parameter int V_SYNC_FRONT = 10,
    parameter int VIEW_X_MIN   = 20,
    parameter int VIEW_X_MAX   = 620,
    parameter int VIEW_Y_MIN   = 260,
    parameter int VIEW_Y_MAX   = 460,
    parameter int SAMPLE_Y_BITS = 9
  )
  (
    input  [15:0] WAVE,
    input  [15:0] WAVE_2,
    input         SAMPLE_CLK,
    input  [1:0]  MODO,
    input         RESET_n,
    input         DRAW_DOT,
    input         PIXEL_CLK,
    input  [31:0] SCAL,
    input         START_STOP,
    output logic [39:0] avalon_data,
    output logic        avalon_valid,
    input               avalon_ready,
    output logic        avalon_startofpacket,
    output logic        avalon_endofpacket
  );

  localparam int H_SYNC_TOTAL = H_SYNC_CYC + H_SYNC_BACK + H_SYNC_ACT + H_SYNC_FRONT;
  localparam int V_SYNC_TOTAL = V_SYNC_CYC + V_SYNC_BACK + V_SYNC_ACT + V_SYNC_FRONT;
  localparam int H_CNT_W      = $clog2(H_SYNC_TOTAL);
  localparam int V_CNT_W      = $clog2(V_SYNC_TOTAL);
  localparam int SUPER_H_W    = $clog2(H_SYNC_TOTAL << 1);
  localparam int SUPER_V_W    = $clog2(V_SYNC_TOTAL << 1);
  localparam int X_START      = H_SYNC_CYC + H_SYNC_BACK;
  localparam int Y_START      = V_SYNC_CYC + V_SYNC_BACK;
  localparam int ACTIVE_X0    = X_START - 2;
  localparam int TRACE_LEN    = 1024;
  localparam int TRACE_ADDR_W = $clog2(TRACE_LEN);
  localparam int VIEW_Y_CENTER = (VIEW_Y_MIN + VIEW_Y_MAX) / 2;
  localparam int Y_MAP_MAX    = (1 << SUPER_V_W) - 1;

  localparam int SENYAL1 = 0;
  localparam int SENYAL2 = 1;

  logic [H_CNT_W-1:0] h_count;
  logic [V_CNT_W-1:0] v_count;
  logic frame_sync;
  logic frame_sync_sample;

  logic [TRACE_ADDR_W-1:0] SW_ADDR;
  logic PW_CH;
  logic PW_CH_PIXEL;
  logic capture_en_sample;

  logic [15:0] VRDAT_1;
  logic [15:0] VRDAT_2;
  logic [15:0] VRDAT2_1;
  logic [15:0] VRDAT2_2;

  logic [9:0] PIX_D_R;
  logic [9:0] PIX_D_G;
  logic [9:0] PIX_D_B;
  logic [9:0] PIX_D_A;

  logic active_video;
  logic [H_CNT_W-1:0] h_vis;
  logic [V_CNT_W-1:0] v_vis;
  logic [H_CNT_W-1:0] h_count_next;
  logic [V_CNT_W-1:0] v_count_next;
  logic active_video_next;
  logic [H_CNT_W-1:0] h_vis_next;

  logic [TRACE_ADDR_W:0] rd_sum;
  logic [TRACE_ADDR_W-1:0] rd_addr;

  logic [SUPER_H_W-1:0] pixel_x;
  logic [SUPER_V_W-1:0] pixel_y;

  logic [SUPER_V_W-1:0] y1_prev;
  logic [SUPER_V_W-1:0] y1_curr;
  logic [SUPER_V_W-1:0] y2_prev;
  logic [SUPER_V_W-1:0] y2_curr;

  logic signed [15:0] ch1_sel;
  logic signed [15:0] ch2_sel;

  function automatic [SUPER_V_W-1:0] map_y_to_view_fixed;
    input logic signed [15:0] s;
    longint signed y_pix;
    begin
      y_pix = VIEW_Y_CENTER - (s >>> 8);
      if (y_pix < 0)
        map_y_to_view_fixed = '0;
      else if (y_pix > $signed(Y_MAP_MAX))
        map_y_to_view_fixed = Y_MAP_MAX[SUPER_V_W-1:0];
      else
        map_y_to_view_fixed = y_pix[SUPER_V_W-1:0];
    end
  endfunction

  Video_AvalonST_Frame_Generator #(
    .H_BLANK_LEAD(H_SYNC_CYC),
    .H_BLANK_PRE(H_SYNC_BACK),
    .H_ACTIVE_PIX(H_SYNC_ACT),
    .H_BLANK_POST(H_SYNC_FRONT),
    .V_BLANK_PRE(V_SYNC_BACK),
    .V_ACTIVE_LINES(V_SYNC_ACT),
    .V_BLANK_LEAD(V_SYNC_CYC),
    .V_BLANK_POST(V_SYNC_FRONT)
  ) frame_st_gen (
    .iAlpha(PIX_D_A),
    .iRed(PIX_D_R),
    .iGreen(PIX_D_G),
    .iBlue(PIX_D_B),
    .oRequest(),
    .avalon_data(avalon_data),
    .avalon_valid(avalon_valid),
    .avalon_ready(avalon_ready),
    .avalon_startofpacket(avalon_startofpacket),
    .avalon_endofpacket(avalon_endofpacket),
    .oFrameSync(frame_sync),
    .hCount(h_count),
    .vCount(v_count),
    .iCLK(PIXEL_CLK),
    .iRST_N(RESET_n)
  );

  assign active_video = (h_count >= ACTIVE_X0) && (h_count < (ACTIVE_X0 + H_SYNC_ACT)) &&
                        (v_count >= Y_START)  && (v_count < (Y_START + V_SYNC_ACT));
  assign h_vis = active_video ? (h_count - ACTIVE_X0) : '0;
  assign v_vis = active_video ? (v_count - Y_START)   : '0;

  assign h_count_next = avalon_ready ? ((h_count == H_SYNC_TOTAL-1) ? '0 : (h_count + 1'b1)) : h_count;
  assign v_count_next = avalon_ready ? ((h_count == H_SYNC_TOTAL-1) ?
                         ((v_count == V_SYNC_TOTAL-1) ? '0 : (v_count + 1'b1)) : v_count) : v_count;
  assign active_video_next = (h_count_next >= ACTIVE_X0) && (h_count_next < (ACTIVE_X0 + H_SYNC_ACT)) &&
                             (v_count_next >= Y_START)  && (v_count_next < (Y_START + V_SYNC_ACT));
  assign h_vis_next = active_video_next ? (h_count_next - ACTIVE_X0) : '0;

  assign rd_sum  = h_vis_next;
  assign rd_addr = (rd_sum >= TRACE_LEN) ? (rd_sum - TRACE_LEN) : rd_sum[TRACE_ADDR_W-1:0];

  assign ch1_sel = PW_CH_PIXEL ? $signed(VRDAT_2)  : $signed(VRDAT_1);
  assign ch2_sel = PW_CH_PIXEL ? $signed(VRDAT2_2) : $signed(VRDAT2_1);

  always_ff @(posedge PIXEL_CLK or negedge RESET_n) begin
    if (!RESET_n) begin
      pixel_x  <= '0;
      pixel_y  <= '0;
      y1_prev  <= '0;
      y1_curr  <= '0;
      y2_prev  <= '0;
      y2_curr  <= '0;
    end
    else begin
      pixel_x <= h_vis;
      pixel_y <= v_vis;

      y1_prev <= y1_curr;
      y1_curr <= map_y_to_view_fixed(ch1_sel);
      y2_prev <= y2_curr;
      y2_curr <= map_y_to_view_fixed(ch2_sel);
    end
  end

  always_comb begin
    {PIX_D_A, PIX_D_R, PIX_D_G, PIX_D_B} = 40'h0000000000;

    if ((pixel_x >= VIEW_X_MIN) && (pixel_x <= VIEW_X_MAX) &&
        (pixel_y >= VIEW_Y_MIN) && (pixel_y <= VIEW_Y_MAX)) begin

      if (MODO[SENYAL1]) begin
        if (((DRAW_DOT == 1'b0) &&
            (((y1_prev > y1_curr) && (pixel_y <  y1_prev) && (pixel_y >= y1_curr)) ||
             ((y1_prev < y1_curr) && (pixel_y >= y1_prev) && (pixel_y <  y1_curr)) ||
             ((y1_prev == y1_curr) && (pixel_y == y1_curr)))) ||
            ((DRAW_DOT == 1'b1) && (pixel_y == y1_curr))) begin
          // Verde para la señal 1
          PIX_D_G = 10'h3FF;
          PIX_D_A = 10'h3FF;
        end
      end

      if (MODO[SENYAL2]) begin
        if (((DRAW_DOT == 1'b0) &&
            (((y2_prev > y2_curr) && (pixel_y <  y2_prev) && (pixel_y >= y2_curr)) ||
             ((y2_prev < y2_curr) && (pixel_y >= y2_prev) && (pixel_y < y2_curr)) ||
             ((y2_prev == y2_curr) && (pixel_y == y2_curr)))) ||
            ((DRAW_DOT == 1'b1) && (pixel_y == y2_curr))) begin
          // Magenta para la señal 2
          PIX_D_R = 10'h3FF;
          PIX_D_B = 10'h3FF;
          PIX_D_A = 10'h3FF;
        end
      end
    end
  end

  sync_2ff u_sync_pw_ch_pixel (
    .clk(PIXEL_CLK),
    .in_signal(PW_CH),
    .out_signal(PW_CH_PIXEL)
  );

  sync_2ff u_sync_frame_sync_sample (
    .clk(SAMPLE_CLK),
    .in_signal(frame_sync),
    .out_signal(frame_sync_sample)
  );

  Trigger_Buffer_Manager #(
    .TRACE_LEN(TRACE_LEN),
    .TRACE_ADDR_W(TRACE_ADDR_W)
  ) u_trigger_buffer_manager (
    .SAMPLE_CLK(SAMPLE_CLK),
    .RESET_n(RESET_n),
    .START_STOP(START_STOP),
    .SCAL(SCAL),
    .WAVE(WAVE),
    .frame_sync_sample(frame_sync_sample),
    .SW_ADDR(SW_ADDR),
    .PW_CH(PW_CH),
    .CAPTURE_EN(capture_en_sample)
  );

  PIPO P1_1 (
    .rdaddress(rd_addr),
    .rdclock(PIXEL_CLK),
    .q(VRDAT_1),
    .data(WAVE),
    .wraddress(SW_ADDR),
    .wrclock(SAMPLE_CLK),
    .wren(PW_CH && capture_en_sample)
  );

  PIPO P1_2 (
    .rdaddress(rd_addr),
    .rdclock(PIXEL_CLK),
    .q(VRDAT_2),
    .data(WAVE),
    .wraddress(SW_ADDR),
    .wrclock(SAMPLE_CLK),
    .wren((~PW_CH) && capture_en_sample)
  );

  PIPO P2_1 (
    .rdaddress(rd_addr),
    .rdclock(PIXEL_CLK),
    .q(VRDAT2_1),
    .data(WAVE_2),
    .wraddress(SW_ADDR),
    .wrclock(SAMPLE_CLK),
    .wren(PW_CH && capture_en_sample)
  );

  PIPO P2_2 (
    .rdaddress(rd_addr),
    .rdclock(PIXEL_CLK),
    .q(VRDAT2_2),
    .data(WAVE_2),
    .wraddress(SW_ADDR),
    .wrclock(SAMPLE_CLK),
    .wren((~PW_CH) && capture_en_sample)
  );

endmodule
