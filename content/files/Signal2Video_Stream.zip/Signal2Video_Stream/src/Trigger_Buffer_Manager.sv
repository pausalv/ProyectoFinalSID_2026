module Trigger_Buffer_Manager #(
    parameter int TRACE_LEN = 1024,
    parameter int TRACE_ADDR_W = $clog2(TRACE_LEN)
  ) (
    input  logic SAMPLE_CLK,
    input  logic RESET_n,
    input  logic START_STOP,
    input  logic [31:0] SCAL,
    input  logic [15:0] WAVE,
    input  logic frame_sync_sample,
    output logic [TRACE_ADDR_W-1:0] SW_ADDR,
    output logic PW_CH,
    output logic CAPTURE_EN
  );

  logic rFrameSync;
  logic [31:0] CNT;
  logic [15:0] WAVE_reg;
  logic WAVE_pulse;
  logic capture_active;

  assign WAVE_pulse = (WAVE_reg[15] == 1'b1 && WAVE[15] == 1'b0);
  assign CAPTURE_EN = START_STOP && capture_active;

  always_ff @(posedge SAMPLE_CLK or negedge RESET_n) begin
    if (!RESET_n) begin
      CNT <= '0;
      SW_ADDR <= '0;
      PW_CH <= 1'b0;
      rFrameSync <= 1'b0;
      WAVE_reg <= '0;
      capture_active <= 1'b0;
    end
    else begin
      rFrameSync <= frame_sync_sample;
      WAVE_reg <= WAVE;

      if (START_STOP) begin
        if (!rFrameSync && frame_sync_sample) begin
          PW_CH <= ~PW_CH;
          SW_ADDR <= '0;
          CNT <= '0;
          capture_active <= 1'b0;
        end
        else begin
          if (CNT == 0) begin
            if (!capture_active) begin
              if (WAVE_pulse) begin
                SW_ADDR <= 'd1;
                capture_active <= 1'b1;
              end
              else begin
                SW_ADDR <= '0;
              end
            end
            else begin
              if (SW_ADDR < (TRACE_LEN-1))
                SW_ADDR <= SW_ADDR + 1'b1;
              else
                SW_ADDR <= SW_ADDR;
            end
          end

          if (CNT >= SCAL) begin
            CNT <= '0;
          end
          else begin
            CNT <= CNT + 1'b1;
          end
        end
      end
      else begin
        CNT <= '0;
        SW_ADDR <= '0;
        capture_active <= 1'b0;
      end
    end
  end

endmodule
